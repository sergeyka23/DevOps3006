
SCORES_FILE_NAME = "Scores.txt"
BAD_RETURN_CODE = 999


def Screen_cleaner():
    print("\n" * 100)
